<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pendaftaran</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            padding: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        h1 {
            font-size: 24px;
            font-weight: bold;
            margin-top: 20px;
        }

        p {
            margin: 5px 0;
        }

        input[type="text"] {
            padding: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
            width: 200px;
        }

        input[type="submit"] {
            padding: 5px 10px;
            background-color: #FFC8EA;
            border: none;
            color: #fff;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #FFB6E3;
        }
    </style>

</head>

<body>
    <form action="/asisten/search" method="post">
        <?= csrf_field() ?>
        Search: <input type="text" name="key" />
        <input type="submit" name="submit" value="search" />
    </form>
</body>

<?php
if (!empty($hasil)) {
    echo "<h1>Hasil Pencarian</h1>";
    echo "Nama:" . $hasil['NAMA'];
    echo "<br>Praktikum:" . $hasil['PRAKTIKUM'];
    echo "<br>IPK:" . $hasil['IPK'];
}
?>

</html>