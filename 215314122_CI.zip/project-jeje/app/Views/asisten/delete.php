<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Hapus Data</title>

    <style>
        body {
            background-color: #f8f9fa;
        }

        .container {
            max-width: 500px;
            margin: 0 auto;
            padding: 20px;
        }

        .jumbotron {
            background-color: #FFC8EA;
            padding: 20px;
            margin-bottom: 20px;
        }

        .display-4 {
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 0;
            text-align: center;
        }

        .form-control {
            margin-top: 10px;
        }

        input[type="submit"] {
            margin-top: 20px;
            padding: 10px 20px;
            font-size: 1.2rem;
            background-color: #FFC8EA;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #FFB6E3;
        }
    </style>

</head>

<body>
    <div class="container">
        <div class="p-4 text-white rounded" style="background-color: #FFC8EA; ">
            <div class="jumbotron">
                <center>
                    <h1 class="display-4">HAPUS DATA ASISTEN</h1>
                </center>
            </div>
        </div>
        <form action="/asisten/delete" method="post">
            <?= csrf_field() ?>
            <div class="p-4 text-black rounded">
                <div class="mb-3 mt-3">
                    NIM
                    <br>
                    <input type="text" class="form-control" id="nim" placeholder="Masukkan NIM" name="nim" required>
                </div>
            </div>
            <center><input type="submit" name="" value="Hapus" /></center>
        </form>
    </div>
</body>

</html>