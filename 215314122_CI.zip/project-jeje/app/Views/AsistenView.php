<!DOCTYPE html>
<html>

<head>
    <title>Pendaftaran Asisten Praktikum</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }

        h1 {
            color: #333333;
        }


        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #cccccc;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        tr:nth-child(even) {
            background-color: #FFC8EA;
        }


        .button-container {
            text-align: center;
            margin-top: 20px;
        }

        .button-container a {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 5px;
            background-color: #FFC8EA;
            color: #333333;
            text-decoration: none;
            border-radius: 5px;
        }

        .button-container a:hover {
            background-color: #FFB6E3;
        }
    </style>
</head>

<body>
    <h1>Pendaftaran Asisten Praktikum</h1>
    <table border="1">
        <thead>
            <tr>
                <th>No</th>
                <th>NIM</th>
                <th>Nama</th>
                <th>Praktikum</th>
                <th>IPK</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1;
            foreach ($asisten as $a) : ?>
                <tr>
                    <td><?= $i++; ?></td>
                    <td><?= $a['NIM']; ?></td>
                    <td><?= $a['NAMA']; ?></td>
                    <td><?= $a['PRAKTIKUM']; ?></td>
                    <td><?= $a['IPK']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <div class="button-container">
        <a href="/asisten/simpan">Tambah Data</a>
        <a href="/asisten/update">Update Data</a>
        <a href="/asisten/delete">Hapus Data</a>
        <a href="/asisten/search">Cari Data</a>
        <a href="/login">Logout</a>
    </div>
</body>

</html>