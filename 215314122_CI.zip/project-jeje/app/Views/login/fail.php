<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: pink;
            /* Mengubah latar belakang menjadi warna pink */
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333333;
            padding: 20px 0;
        }
    </style>
</head>

<body>
    <h1>Anda gagal login</h1>
</body>

</html>